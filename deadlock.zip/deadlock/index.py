import os
import sys


def main(error=""):
    import com_func

    com_func.clear_screen()
    print(error)
    print("=" * 30)
    print("1- Programı Çalıştır")
    print("|")
    print("2- Ayarlar")
    print("=" * 30)

    choice = input("\nLütfen bir senaryo seçiniz: ")

    if choice == "1":
        import project

        project.main()

    elif choice == "2":
        import options

        options.main()

    else:
        main("Geçerli bir değer giriniz.")


if __name__ == "__main__":
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))

        sys.path.append(os.path.join(current_dir, "req"))
        sys.path.append(os.path.join(current_dir, "req", "scenarios"))
        sys.path.append(os.path.join(current_dir, "scripts"))
        sys.path.append(os.path.join(current_dir, "scripts", "algorithms"))

        main()

    except KeyboardInterrupt as e:
        print("\n\nProgram sonlandırıldı.")
