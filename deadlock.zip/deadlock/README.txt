========================================================================
PİRİ REİS ÜNİVERSİTESİ - DENİZCİLİK MESLEK YÜKSEKOKULU
BİLGİSAYAR PROGRAMCILIĞI - İŞLETİM SİSTEMLERİ DERSİ PROJESİ
========================================================================

PROJE ADI : İşletim Sistemlerinde Deadlock (Kilitlenme) Simülasyonu
ÖĞRENCİ   : Emir Ecrin MALKOÇ
ÖĞRENCİ NO: 20240108044
TESLİM TARİHİ: 07.01.2026

------------------------------------------------------------------------
1. PROJE HAKKINDA
------------------------------------------------------------------------
Bu proje, işletim sistemlerinde meydana gelen Deadlock (Ölümcül Kilitlenme)
durumlarını analiz etmek ve farklı algoritmaların performanslarını
karşılaştırmak amacıyla geliştirilmiş dinamik bir simülatördür.

Simülasyon şunları içerir:
- 4 farklı kategoride 7 algoritma (banker, resource orrdering, rollback vb.)
- Çeşitli test senaryoları (dining philosophers, starvation, chaos vb.)
- Sonuçların grafiksel olarak karşılaştırılması (matplotlib)

------------------------------------------------------------------------
2. KURULUM VE GEREKSİNİMLER
------------------------------------------------------------------------
Bu proje Python 3.x sürümü ile geliştirilmiştir. Grafik çizimi için
harici bir kütüphane gereklidir.

Gerekli Kütüphanenin Kurulumu:
Terminal veya Komut İstemi'nde (CMD) şu komutu çalıştırınız:

    pip install matplotlib

------------------------------------------------------------------------
3. NASIL ÇALIŞTIRILIR?
------------------------------------------------------------------------
Simülasyonu başlatmak için ana dizindeki "index.py" dosyası çalıştırılmalıdır.

Adım 1: Terminali projenin bulunduğu klasörde açın.
Adım 2: Aşağıdaki komutu girin:

    python index.py

Adım 3: Açılan menüden seçim yapın:
    - [1] Programı Çalıştır: Mevcut ayarlarla simülasyonu başlatır.
    - [2] Ayarlar: Senaryo değiştirmek veya algoritma açıp kapatmak için.

Adım 4: Simülasyon tamamlandığında, performans analiz grafikleri
otomatik olarak ekrana gelecektir (eğer seçili algoritma var ise).

------------------------------------------------------------------------
4. DOSYA YAPISI
------------------------------------------------------------------------
/req/scenarios/       -> Test senaryoları (JSON formatında) burada bulunur.
/scripts/algorithms/  -> Algoritma kodları (banker, rollback vb.) burada bulunur.
/scripts/graphic.py           -> Matplotlib çizim modülü.
/scripts/project.py           -> Simülasyonun çekirdek motoru.

------------------------------------------------------------------------
5. NOTLAR
------------------------------------------------------------------------
- Varsayılan olarak tüm algoritmalar seçilidir. "Ayarlar" menüsünden
  istediğiniz algoritmaları kapatabilirsiniz.
- Grafik pencereleri kapatıldığında program kapanır.