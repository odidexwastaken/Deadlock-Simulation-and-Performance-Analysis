import os
import json

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def clear_screen():
    os.system("cls")


def get_path(*args):

    return os.path.join(ROOT_DIR, *args)


def get_file_list(folder_path, extension):
    full_path = get_path(folder_path)

    return [
        f
        for f in os.listdir(full_path)
        if f.endswith(extension) and not f.startswith("__")
    ]


def load_json(rel_path):
    try:
        with open(get_path(rel_path), "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}


def save_json(rel_path, data):
    try:
        with open(get_path(rel_path), "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"Kayıt Hatası: {e}")
