import matplotlib.pyplot as plt

def plot_comparison(results, scenario):
    # verileri ayrıştırma
    names = [r['algorithm_name'] for r in results]
    exec_times = [r['total_execution_time'] for r in results]
    overheads = [r['algorithm_overhead'] for r in results]
    kill_counts = [r['kill_count'] for r in results]
    wasted_values = [r['wasted_value'] for r in results]

    # 2 satır 2 sütunluk bir pencere açıyoruz 4 grafiklik
    fig, axs = plt.subplots(2, 2, figsize=(15, 10))
    fig.suptitle(f'Deadlock Algoritmaları Karşılaştırma Analizi ({scenario})', fontsize=16, fontweight='bold')

    # toplam çalışma süresi grafiği
    # sol üst
    axs[0, 0].bar(names, exec_times, color='skyblue', edgecolor='black')
    axs[0, 0].set_title('Toplam Çalışma Süresi (Daha Düşük = Daha İyi)')
    axs[0, 0].set_ylabel('Birim Zaman (Tick)')
    axs[0, 0].grid(axis='y', linestyle='--', alpha=0.7)

    # barların üzerine değerleri yazma
    for i, v in enumerate(exec_times):
        axs[0, 0].text(i, v + 0.5, str(v), ha='center', fontweight='bold')

    # algoritma maliyeti grafiği
    # sağ üst
    axs[0, 1].bar(names, overheads, color='orange', edgecolor='black')
    axs[0, 1].set_title('Algoritma Maliyeti/Overhead (Daha Düşük = Daha İyi)')
    axs[0, 1].set_ylabel('Maliyet Puanı')
    axs[0, 1].grid(axis='y', linestyle='--', alpha=0.7)
    for i, v in enumerate(overheads):
        axs[0, 1].text(i, v + 0.5, str(v), ha='center', fontweight='bold')

    # öldürülen işlem grafiği
    # sol alt
    axs[1, 0].bar(names, kill_counts, color='red', edgecolor='black')
    axs[1, 0].set_title('Öldürülen Process Sayısı (Stability)')
    axs[1, 0].set_ylabel('Adet')
    y_max_kill = max(kill_counts) if kill_counts else 0
    axs[1, 0].set_yticks(range(int(y_max_kill) + 2)) 
    axs[1, 0].grid(axis='y', linestyle='--', alpha=0.7)
    for i, v in enumerate(kill_counts):
        axs[1, 0].text(i, v + 0.1, str(v), ha='center', fontweight='bold')

    # ziyan edilen değerli işlem grafiği
    # sağ alt
    axs[1, 1].bar(names, wasted_values, color='purple', edgecolor='black')
    axs[1, 1].set_title('Ziyan Edilen Değer (Loss Analysis)')
    axs[1, 1].set_ylabel('Puan (Value)')
    
    y_max_waste = max(wasted_values) if wasted_values else 0
    if y_max_waste < 20:
        axs[1, 1].set_yticks(range(int(y_max_waste) + 2))
        
    axs[1, 1].grid(axis='y', linestyle='--', alpha=0.7)
    
    # Değerleri barların üzerine yazalım
    for i, v in enumerate(wasted_values):
        axs[1, 1].text(i, v + 0.1, str(v), ha='center', fontweight='bold')

    # BURASI EKLENDİ: Tüm grafiklerin x ekseni yazılarını eğip büküyoruz
    for ax in axs.flat:
        ax.set_xticklabels(names, rotation=20, ha='right')

    # yazıların gözükmesi için düzenleme
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    plt.show()

def main(data, scenario):
    
    print("Grafikler çiziliyor...")
    plot_comparison(data, scenario)
    print("Program başarıyla sonlandırıldı...")