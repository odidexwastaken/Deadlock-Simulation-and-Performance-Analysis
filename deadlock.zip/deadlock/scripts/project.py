import importlib

import com_func



#  LOGLAMA 

def debug_print(message, is_debug_on):
    if is_debug_on:
        print(message)



#  YARDIMCI FONKSİYONLAR 

# scripti çevirme
# gönderilen işlemin senaryo dosyasındai satır satır işlemlerini algoritmaların daha rahat anlayacağı yapıya çevirir

def parse_script(script_list):
    steps = []
    for line in script_list:
        parts = line.split()
        cmd = parts[0].upper()
        if cmd == "GET":
            steps.append({"command": "request", "resource": parts[1], "amount": int(parts[2])})
        elif cmd == "CPU":
            steps.append({"command": "compute", "duration": int(parts[1])})
        elif cmd == "REL":
            if parts[1].upper() == "ALL":
                steps.append({"command": "release_all"})
            else:
                steps.append({"command": "release", "resource": parts[1], "amount": int(parts[2])})
    return steps

# maksimum kaynak isteği hesaplama (banker için)
# her komut satırında kaynağa istek yapıyor mu diye bakar, yapıyorsa ise hangi kaynaktan ne kadar istediğini ayrı ayrı kaydeder

def calculate_max_needs(steps, total_resources):
    max_needs = {r: 0 for r in total_resources}
    current = {r: 0 for r in total_resources}
    for step in steps: 
        if step["command"] == "request":
            res = step["resource"]
            amt = step["amount"]
            current[res] += amt
            if current[res] > max_needs[res]:
                max_needs[res] = current[res]
    return max_needs

# beyin dictionary yapısını hazırlama
# simülasyonun ve algoritmaların veri alışverişi yapacağı ana dictionary yapısı
# program sonunda karşılaştırılacak istatistiksel verileri tutacağımız dictionary yapısını oluşturur 

def initialize_simulation(scenario_data):
    state = {
        "resources_total": scenario_data["total_resources"].copy(), # toplam kaynak kapasitesi listesi
        "resources_available": scenario_data["total_resources"].copy(), # toplam kaynak kapasitesi listesi, kullanıldıkça değişecek
        "processes": [],                # işlemlerin listesi, 
        "time_step": 0,                 # zaman birimi
        "finished_processes": 0,        # biten iş sayısı
        "stats": {                      # istatistik dictionary 
            "total_execution_time": 0,  # ne kadar sürdü
            "wasted_value": 0,          # öldürülen işlemlerin önemi priority
            "kill_count": 0,            # kaç işlem öldü
            "algorithm_overhead": 0,    # algoritma işlem maliyeti
            "success": False            # sonuç başarılı mı
        }
    }

    # processleri tek tek oluşturup listeliyoruz
    for p_data in scenario_data["processes"]:
        detailed_steps = parse_script(p_data["script"])
        max_needs = calculate_max_needs(detailed_steps, scenario_data["total_resources"])

        process_state = {
            "id": p_data["id"],
            "value": p_data.get("value", 0),            # process value değeri
            "steps": detailed_steps,                    # yapacağı işlerin listesi
            "pc": 0,                                    # program counter, "işlem sırası hangi satırda?"
            "current_compute_left": 0,                  # cpu işlemi yapıyorsa kaç saniyesi kaldı
            "holding": {r: 0 for r in scenario_data["total_resources"]}, # elinde tuttuğu kaynaklar
            "status": "ready",                          # durum bilgisi: ready, running, waiting, finished
            "max_needs": max_needs,                     # maksimum kaynak ihtiyacı, banker için
        }
        state["processes"].append(process_state)
    return state



#  ÇEKİRDEK FONKSİYONLAR 

# yeterli kaynak var mı, algoritmasız çalıştırma için
# true-false

def check_resource_availability(state, resource, amount):

    return state["resources_available"][resource] >= amount

# kaynağı tahsis etme
# seçili kaynağı resources_available'dan düşer, o process'in tuttuğu kaynaklar arasına alır

def allocate_resource(state, process, resource, amount, is_debug=False):
    state["resources_available"][resource] -= amount
    process["holding"][resource] += amount

    log_msg = f"    -{process['id']} -> {resource} ({amount}) ALDI."

    debug_print(log_msg, is_debug)

# kaynağı salma
# process'in tuttuğu kaynaklardan belirtilen miktarda alıp resources_available'a ekler 

def release_resource(state, process, resource, amount, is_debug=False):
    state["resources_available"][resource] += amount
    process["holding"][resource] -= amount

    log_msg = f"    -{process['id']} -> {resource} ({amount}) BIRAKTI."

    debug_print(log_msg, is_debug)



#  SİMÜLASYON 
# her algoritma için ayrı ayrı çalışır ve her biri için istatistiksel veri döner 

def run_simulation(scenario_data_template, algorithm_func, algo_name, is_debug):
    state = initialize_simulation(scenario_data_template)
    total_processes = len(state["processes"])

    debug_print(f"\n SİMÜLASYON LOGLARI: {algo_name} ", is_debug)

    while state["finished_processes"] < total_processes:
        state["time_step"] += 1
        debug_print(f"\n  -Tick {state['time_step']}", is_debug)

        # tick başı kasadaki kaynak, deadlock kontrolü 
        start_resources = sum(state["resources_available"].values())

        # deadlock kontrolü için boolean, o döngüde işlem yapılmış ise True olarak tetikleniyor
        progress_made = False

        for process in state["processes"]:

            # işlem bittiyse direkt geç
            if process["status"] == "finished": 

                continue

            # process mevcut cpu işlemi devam ediyorsa

            if process["current_compute_left"] > 0:
                process["current_compute_left"] -= 1
                
                # process cpu işlemi bittiyse
                if process["current_compute_left"] == 0:
                    process["pc"] += 1
                    process["status"] = "ready"

                    debug_print(f"    -{process['id']} CPU işlemini tamamladı.", is_debug)

                else:
                    debug_print(f"    -{process['id']} İşlemci Kullanıyor (Kalan: {process['current_compute_left']} tick)", is_debug)
                
                progress_made = True

                continue

            # process senaryodaki satır sayısını geçtiyse, bittiyse

            if process["pc"] >= len(process["steps"]):
                process["status"] = "finished"
                state["finished_processes"] += 1
                progress_made = True

                continue



            # PROCESS KOMUT OKUMA

            # process'in o satırdaki komudunu al
            step = process["steps"][process["pc"]]
            command = step["command"]

            # process cpu

            if command == "compute":
                duration = step["duration"]
                process["current_compute_left"] = duration - 1
                
                if process["current_compute_left"] == 0:
                    process["pc"] += 1
                    debug_print(f"    -{process['id']} CPU işlemini başlattı ve bitirdi (1 tick).", is_debug)

                else:
                    debug_print(f"    -{process['id']} CPU işlemine başladı (Süre: {duration} tick, Kalan: {process['current_compute_left']} tick)", is_debug)

                process["status"] = "running"
                progress_made = True
                
            # process kaynak isteme, algoritmaların devreye girdiği yer

            elif command == "request":
                res = step["resource"]
                amt = step["amount"]
                
                decision, cost = algorithm_func(state, process, res, amt, is_debug)
                state["stats"]["algorithm_overhead"] += cost

                if decision:
                    allocate_resource(state, process, res, amt, is_debug)
                    process["pc"] += 1
                    process["status"] = "running"
                    progress_made = True
                else:
                    process["status"] = "waiting"
                    debug_print(f"    -{process['id']} BEKLİYOR ({res})", is_debug)
            
            # process kaynak bırak

            elif command == "release":
                release_resource(state, process, step["resource"], step["amount"], is_debug)
                process["pc"] += 1
                progress_made = True
                
            elif command == "release_all":
                to_release = process["holding"].copy()
                for res, amt in to_release.items():
                    if amt > 0: release_resource(state, process, res, amt, is_debug)
                process["pc"] += 1
                progress_made = True

        # tick sonu kasadaki kaynak
        end_resources = sum(state["resources_available"].values())
        
        if end_resources > start_resources:
            progress_made = True
            debug_print("      [Sistem]   Kaynaklar serbest kaldı, sistem akmaya devam ediyor...", is_debug)

        if not progress_made and state["finished_processes"] < total_processes:
            debug_print(f"    -DEADLOCK! (Step: {state['time_step']})", is_debug)

            break

    # raporlama

    state["stats"]["total_execution_time"] = state["time_step"]
    state["stats"]["success"] = (state["finished_processes"] == total_processes)
    
    print('-' * 40)
    status_text = 'BAŞARILI' if state["stats"]["success"] else 'KİLİTLENDİ'
    print(f"SONUÇ [{algo_name}]: {status_text}")
    print(f"Süre: {state['time_step']} Tick | Maliyet: {state['stats']['algorithm_overhead']}")
    print('-' * 40)

    return state["stats"]

#  DİNAMİK ALGORİTMA YÖNETİCİSİ 

def main():
    com_func.clear_screen()
    settings = com_func.load_json("req/options.json")
    if not settings: return

    scenario_file = settings["scenario"]
    algo_list = settings.get("algorithms", [])
    is_debug = settings.get("debug", False)

    print("=" * 50)
    print(f"Senaryo: {scenario_file}")
    print(f"Algoritmalar: {algo_list}")
    print("=" * 50)

    scenario_data = com_func.load_json(f"req/scenarios/{scenario_file}")
    if not scenario_data:
        print("Senaryo yüklenemedi.")
        return

    graph_data = [] 

    if not algo_list:
        print(
            "\n>>> Algoritma seçilmedi. Varsayılan modda çalışıyor. <<<"
        )

        default_func = lambda state, proc, res, amt, is_debug: (
            check_resource_availability(state, res, amt),
            0,
        )
        run_simulation(scenario_data, default_func, "No Algo", is_debug)
    else:
        for algo_file in algo_list:
            algo_name = algo_file.replace(".py", "")
            try:
                module = importlib.import_module(algo_name) # dinamik algoritma import
                if hasattr(module, "check_request"):
                    print(f"\n    ÇALIŞTIRILIYOR: {algo_name}")
                    
                    stats = run_simulation(scenario_data, module.check_request, algo_name, is_debug)
                    stats["algorithm_name"] = algo_name
                    
                    graph_data.append(stats)
                    
                else:
                    print(f"{algo_file} içinde 'check_request' yok.")
            except ImportError:
                try:
                    module = importlib.import_module(f"{algo_name}")

                    pass
                except:
                    print(f"{algo_file} yüklenemedi.")

    if graph_data:
        print("\n Grafik Verileri Toplandı. Çizim modülü bekleniyor...")
        
        import graphic
        graphic.main(graph_data, scenario_file)
    
if __name__ == "__main__":
    main()