def check_request(state, process, request_res, request_amount, is_debug=False):
    # hafızaya işlemleri kaydetme
    OVERHEAD_COST = 10 
    
    # kaynak kontrolü
    available = state["resources_available"]
    if available[request_res] >= request_amount:
        return True, 1

    # deadlock kontrolü
    cycle_path = detect_cycle(state, process, request_res)
    
    if not cycle_path:
        if is_debug: print(f"      [Rollback]  Bekliyor... (Güvenli bekleme)")
        return False, OVERHEAD_COST
    
    # deadlock varsa: ROLLBACK OPERASYONU
    # deadlock u tetikleyen process (mevcut process) kendini feda eder (geri sarar)
    # bu sayede diğerleri yollarına devam eder
    
    if is_debug: print(f"      [Rollback]  DEADLOCK RİSKİ! Döngü: {cycle_path}")

    # mevcut işlemi geri sar
    perform_rollback(state, process, is_debug)
    
    return False, OVERHEAD_COST

def perform_rollback(state, process, is_debug):
    # bu işlem bir "kill" değildir, istatistiklerde kill_count artmaz
    # ancak sisteme zaman/işlem maliyeti bindirir
    
    dropped_resources = []
    
    # elindeki tüm kaynakları kasaya geri bırak
    for res, amt in process["holding"].items():
        if amt > 0:
            state["resources_available"][res] += amt
            process["holding"][res] = 0
            dropped_resources.append(f"{res}({amt})")

    if is_debug:
        print(f"      [Rollback]  {process['id']} zamanı geriye sardı.")
        print(f"      [Rollback]  İade edilen kaynaklar: {dropped_resources}")
        print(f"      [Rollback]  Process PC {process['pc']} -> 0 noktasına çekildi.")

    # process i başa sar
    process["pc"] = 0 
    process["current_compute_left"] = 0
    process["status"] = "ready"



# YARDIMCI FONKSİYONLAR

def detect_cycle(state, current_process, request_res):
    wfg = {}
    for p in state["processes"]:
        if p["status"] == "waiting":
            step = p["steps"][p["pc"]]
            if step["command"] == "request":
                add_dependencies(state, wfg, p["id"], step["resource"])
    
    add_dependencies(state, wfg, current_process["id"], request_res)
    
    visited = set()
    stack = []
    return find_cycle_dfs(wfg, current_process["id"], visited, stack)

def add_dependencies(state, graph, waiter_id, resource_name):
    if waiter_id not in graph: graph[waiter_id] = []
    for p in state["processes"]:
        if p["holding"][resource_name] > 0 and p["id"] != waiter_id:
            graph[waiter_id].append(p["id"])

def find_cycle_dfs(graph, node, visited, stack):
    visited.add(node)
    stack.append(node)
    if node in graph:
        for neighbor in graph[node]:
            if neighbor not in visited:
                result = find_cycle_dfs(graph, neighbor, visited, stack)
                if result: return result
            elif neighbor in stack:
                return stack[stack.index(neighbor):]
    stack.pop()
    return None