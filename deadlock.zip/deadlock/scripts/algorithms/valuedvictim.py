def check_request(state, process, request_res, request_amount, is_debug=False):
    # grafik tarama + sıralama
    OVERHEAD_COST = 4
    
    # 1. Kaynak varsa ver
    available = state["resources_available"]
    if available[request_res] >= request_amount:
        return True, 1

    # 2. Deadlock Kontrolü
    cycle_path = detect_cycle(state, process, request_res)
    
    if not cycle_path:
        if is_debug: print(f"      [Detect-Value] ⏳ Bekliyor... (Döngü yok)")
        return False, OVERHEAD_COST
    
    # deadlock tespit edildi
    if is_debug: 
        print(f"      [Detect-Value]   DEADLOCK TESPİT EDİLDİ! Döngü: {cycle_path}")

    # kurban seçimi
    victim_id = select_victim_by_value(state, cycle_path, is_debug)
    
    # infaz
    if victim_id:
        kill_victim(state, victim_id, is_debug)
    
    return False, OVERHEAD_COST

# değer bazlı kurban seçim fonksiyonu

def select_victim_by_value(state, cycle_ids, is_debug):
    candidates = []
    
    # döngüdeki id leri process objelerine çevir
    for pid in cycle_ids:
        # state içinden process objesini bul
        proc = next((p for p in state["processes"] if p["id"] == pid), None)
        if proc:
            candidates.append(proc)
    
    if not candidates: 

        return None

    # önce value değerine, eşitse pc deki sıralamasına göre
    
    candidates.sort(key=lambda x: (x.get("value", 0), x["pc"]))
    
    victim = candidates[0] # en değersiz
    
    if is_debug:
        print(f"      [Detect-Value] 🔍 Analiz: {[(p['id'], p.get('value',0)) for p in candidates]}")
        print(f"      [Detect-Value] 🎯 Hedef: {victim['id']} (Value: {victim.get('value',0)})")
        
    return victim["id"]

# YARDIMCI FONKSİYONLAR

# döngüyü yakala

def detect_cycle(state, current_process, request_res):
    # wait-for grafiği
    wfg = {}

    # mevcut bekleyenleri grafiğe ekle
    for p in state["processes"]:
        if p["status"] == "waiting":
            step = p["steps"][p["pc"]]
            if step["command"] == "request":

                add_dependencies(state, wfg, p["id"], step["resource"])
    
    # grafiğe hayali olarak ekle    
    add_dependencies(state, wfg, current_process["id"], request_res)
    
    # dfs
    visited = set()
    stack = []

    return find_cycle_dfs(wfg, current_process["id"], visited, stack)


# o kaynağı elinde tutan diğer process leri grafiğe ekle

def add_dependencies(state, graph, waiter_id, resource_name):
    if waiter_id not in graph: 
        graph[waiter_id] = []

    for p in state["processes"]:
        # eğer p kaynağı elinde tutuyorsa
        if p["holding"][resource_name] > 0 and p["id"] != waiter_id:
            graph[waiter_id].append(p["id"])

# dfs algoritması

def find_cycle_dfs(graph, node, visited, stack):
    visited.add(node)
    stack.append(node)

    if node in graph:
        for neighbor in graph[node]:
            if neighbor not in visited:
                result = find_cycle_dfs(graph, neighbor, visited, stack)
                
                if result: 

                    return result

            elif neighbor in stack:

                return stack[stack.index(neighbor):]
    stack.pop()

    return None

# process i öldür

def kill_victim(state, victim_id, is_debug):
    victim = next((p for p in state["processes"] if p["id"] == victim_id), None)
    if not victim: 

        return

    # istatistik
    state["stats"]["kill_count"] += 1
    state["stats"]["wasted_value"] += victim.get("value", 0)

    log_prefix = f"      [randomvictim]  İNFAZ:"
    msg = f"{log_prefix} {victim_id} kurban seçildi ve ÖLDÜRÜLDÜ."
    if is_debug: 
        print(msg)

    # kaynak iade et
    dropped_resources = []
    for res, amt in victim["holding"].items():
        if amt > 0:
            state["resources_available"][res] += amt
            victim["holding"][res] = 0 # cepleri boşalt
            dropped_resources.append(f"{res}({amt})")
            
    if dropped_resources and is_debug:
        print(f"      ---> Geri alınan kaynaklar: {dropped_resources}")

    # process i sıfırla
    victim["pc"] = 0
    victim["current_compute_left"] = 0
    victim["status"] = "ready"