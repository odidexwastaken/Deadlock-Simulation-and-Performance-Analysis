def check_request(state, process, request_res, request_amount, is_debug=False):
    # algoritma maliyeti
    OVERHEAD_COST = 2 
    
    # eldeki kaynak yeterli mi diye bak
    available = state["resources_available"]
    if available[request_res] < request_amount:
        reason = f"Kaynak Yetersiz ({available[request_res]} < {request_amount})"
        if is_debug: 
            print(f"      [banker]  -Red: {reason}")

        return False, 1 
    
    # simulasyon icin gecici kopya olustur
    work = available.copy()
    work[request_res] -= request_amount
    
    # sistem guvenli mi diye kontrol et
    is_safe = check_safety_cycle(state, work, process, request_res, request_amount)
    
    # eger guvenliyse onayla
    if is_safe:
        if is_debug: 
            print(f"      [banker]  -Onay: Sistem Güvenli")

        return True, OVERHEAD_COST 
    else:
        # guvenli degilse reddet
        if is_debug: 
            print(f"      [banker]  -KORUMA: '{process['id']}' isteği reddedildi (Unsafe State riski!)")
        
        return False, OVERHEAD_COST

def check_safety_cycle(state, work, current_process, req_res, req_amt):
    # biten islemleri takip etmek icin liste
    finish = {p["id"]: (p["status"] == "finished") for p in state["processes"]}
    num_processes = len(state["processes"])
    
    # sonsuz dongu baslat
    while True:
        progress = False
        # butun islemleri tek tek gez
        for p in state["processes"]:
            pid = p["id"]

            # islem zaten bitmisse atla
            if finish[pid]: 
                continue
            
            can_finish = True

            # kaynak ihtiyaclarini kontrol et
            for r in state["resources_total"]:
                holding = p["holding"][r]
                if pid == current_process["id"] and r == req_res:
                    holding += req_amt
                
                need = p["max_needs"][r] - holding

                # ihtiyac eldekinden fazlaysa yapilamaz
                if need > work[r]:
                    can_finish = False
                    break
            
            # eger islem yapilabiliyorsa
            if can_finish:
                # kaynaklari geri al ve bitir
                for r in state["resources_total"]:
                    holding = p["holding"][r]

                    if pid == current_process["id"] and r == req_res:
                        holding += req_amt
                    work[r] += holding
                
                finish[pid] = True
                progress = True
        
        # hic ilerleme yoksa donguden cik
        if not progress: 
            break
            
    # hepsi bittiyse true don
    return all(finish.values())