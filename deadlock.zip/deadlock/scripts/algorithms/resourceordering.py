def check_request(state, process, request_res, request_amount, is_debug=False):
    # sıradan bir if, ekstrem bir işlem yok
    OVERHEAD_COST = 0 
    
    sorted_resources = sorted(list(state["resources_total"].keys()))
    req_rank = sorted_resources.index(request_res)
    
    current_max_rank = -1
    holding_resources = []
    
    for res, amt in process["holding"].items():
        if amt > 0:
            rank = sorted_resources.index(res)
            holding_resources.append(f"{res}({rank})")
            if rank > current_max_rank:
                current_max_rank = rank
            
    # sıralama uygun değil
    if req_rank <= current_max_rank:
        msg = f"      [ordering]  -KURAL İHLALİ: {process['id']} için {request_res} (Rütbe {req_rank}) istenemez. Elde yüksek {holding_resources} var."

        if is_debug: 
            print(msg)

        # sıralama ihlalinde kaynakları bırak (R1>R0, REL R1)

        resources_to_release = list(process["holding"].keys())
        
        for res_to_rel in resources_to_release:
            amt = process["holding"][res_to_rel]
            if amt > 0:
                # kasaya geri koy
                state["resources_available"][res_to_rel] += amt
                # processin elinden al
                process["holding"][res_to_rel] = 0
                
                release_msg = f"      [ordering]  -{process['id']} kural ihlali yaptığı için {res_to_rel} ({amt}) BIRAKMAYA ZORLANDI."

                if is_debug: 
                    print(release_msg)
                
        return False, OVERHEAD_COST

    # sıralama uygun, kaynak kontrolü
    available = state["resources_available"][request_res]
    
    # kaynak var, çök
    if available >= request_amount:
        if is_debug: print(f"      [ordering]  -Onay: Sıralama uygun ({req_rank} > {current_max_rank}) ve kaynak var.")

        return True, OVERHEAD_COST

    # kaynak yok, bekle
    else:
        if is_debug: print(f"      [ordering]  -Bekle: Sıralama uygun ama kaynak yok.")

        return False, OVERHEAD_COST