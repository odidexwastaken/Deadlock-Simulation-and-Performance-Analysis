def check_request(state, process, request_res, request_amount, is_debug=False):
    # grafik tarama + sıralama
    OVERHEAD_COST = 5
    
    # kaynak kasada varsa direkt ver
    available = state["resources_available"]
    if available[request_res] >= request_amount:
        return True, 1

    # deadlock kontrolü
    cycle_path = detect_cycle(state, process, request_res)
    
    # döngü yoksa bekleme moduna al
    if not cycle_path:
        if is_debug: print(f"      [Max-Victim]  Bekliyor... (Henüz döngü yok)")
        return False, OVERHEAD_COST
    
    # deadlock varsa
    if is_debug: 
        print(f"      [Max-Victim]  DEADLOCK! Döngü: {cycle_path}")

    victim_id = select_victim_by_max_holding(state, cycle_path, is_debug)
    
    # infaz işlemi
    if victim_id:
        kill_victim(state, victim_id, is_debug)
    
    return False, OVERHEAD_COST

def select_victim_by_max_holding(state, cycle_ids, is_debug):
    candidates = []
    
    # id leri process objesine çevir
    for pid in cycle_ids:
        proc = next((p for p in state["processes"] if p["id"] == pid), None)
        if proc:
            candidates.append(proc)
    
    if not candidates: 
        return None

    # sıralama kriteri:
    # 1. elindeki toplam kaynak sayısı (Azalan)
    # 2. eşitlik durumunda process id (Alfabetik)
    
    candidates.sort(key=lambda x: (sum(x["holding"].values()), x["id"]), reverse=True)
    
    victim = candidates[0] # listenin başındaki zengin process
    
    if is_debug:
        analysis = [(p['id'], sum(p['holding'].values())) for p in candidates]
        print(f"      [Max-Victim]  Zenginlik Analizi (ID, Kaynak): {analysis}")
        print(f"      [Max-Victim]  Hedef: {victim['id']} (Toplam {sum(victim['holding'].values())} kaynak tutuyor)")
        
    return victim["id"]



# YARDIMCI FONKSİYONLAR

def detect_cycle(state, current_process, request_res):
    wfg = {}
    for p in state["processes"]:
        if p["status"] == "waiting":
            step = p["steps"][p["pc"]]
            if step["command"] == "request":
                add_dependencies(state, wfg, p["id"], step["resource"])
    
    add_dependencies(state, wfg, current_process["id"], request_res)
    
    visited = set()
    stack = []
    return find_cycle_dfs(wfg, current_process["id"], visited, stack)

def add_dependencies(state, graph, waiter_id, resource_name):
    if waiter_id not in graph: graph[waiter_id] = []
    for p in state["processes"]:
        if p["holding"][resource_name] > 0 and p["id"] != waiter_id:
            graph[waiter_id].append(p["id"])

def find_cycle_dfs(graph, node, visited, stack):
    visited.add(node)
    stack.append(node)
    if node in graph:
        for neighbor in graph[node]:
            if neighbor not in visited:
                result = find_cycle_dfs(graph, neighbor, visited, stack)
                if result: return result
            elif neighbor in stack:
                return stack[stack.index(neighbor):]
    stack.pop()
    return None

def kill_victim(state, victim_id, is_debug):
    victim = next((p for p in state["processes"] if p["id"] == victim_id), None)
    if not victim: return

    state["stats"]["kill_count"] += 1
    state["stats"]["wasted_value"] += victim.get("value", 0)

    if is_debug: 
        print(f"      [Max-Victim]  İNFAZ: {victim_id} çok fazla kaynak tuttuğu için harcandı.")

    for res, amt in victim["holding"].items():
        if amt > 0:
            state["resources_available"][res] += amt
            victim["holding"][res] = 0
            
    victim["pc"] = 0
    victim["current_compute_left"] = 0
    victim["status"] = "ready"