import com_func

def scenario_menu(settings, error=""):
    com_func.clear_screen()
    files = com_func.get_file_list("req/scenarios", ".json")
    current = settings.get("scenario")

    print(error)
    print("--- SENARYOLAR ---")
    for i, f in enumerate(files, 1):
        mark = " [SEÇİLİ]" if f == current else ""
        print(f"{i}. {f}{mark}")

    choice = input("\nSeçilecek senaryo no (Q: Geri): ").strip().upper()

    if choice == "Q":
        return main()

    elif choice.isdigit() and 0 < int(choice) <= len(files):
        settings["scenario"] = files[int(choice) - 1]
        com_func.save_json("req/options.json", settings)

        return scenario_menu(settings, "Senaryo Başarıyla Güncellendi.")

    else:
        return scenario_menu(settings, "Girilen değer geçersiz.")


def algorithm_menu(settings, error=""):
    com_func.clear_screen()
    files = com_func.get_file_list("scripts/algorithms", ".py")

    selected = settings.get("algorithms", [])

    print(error)
    print("--- ALGORİTMALAR ---")
    for i, f in enumerate(files, 1):
        mark = " [X]" if f in selected else " [ ]"
        print(f"{i}. {mark} {f}")

    choice = input("\nToggle Algoritma No (Q: Geri): ").strip().upper()

    if choice == "Q":
        return main()

    elif choice.isdigit() and 0 < int(choice) <= len(files):
        target = files[int(choice) - 1]

        if target in selected:
            selected.remove(target)
        else:
            selected.append(target)

        settings["algorithms"] = selected
        com_func.save_json("req/options.json", settings)

        return algorithm_menu(settings, "Algoritma Listesi Güncellendi.")

    else:
        return algorithm_menu(settings, "Girilen değer geçersiz.")


def main(error=""):
    com_func.clear_screen()
    settings = com_func.load_json("req/options.json")

    scen_txt = settings.get("scenario", "YOK")
    algorithms = ", ".join(settings.get("algorithms", []))
    debug_status = settings.get("debug")

    print(error)
    print(
        f"----- AYARLAR -----\nSenaryo: {scen_txt}\nAlgoritmalar: {algorithms} \nDebug Modu: {debug_status}\n"
    )
    print("1. Senaryo Seç")
    print("2. Algoritmaları Yönet")
    print("3. Debug Modu (Aç/Kapa)")
    print("4. Kaydet ve Geri Dön")

    choice = input("\nSeçim: ").strip()

    if choice == "1":
        
        return scenario_menu(settings)
    elif choice == "2":

        return algorithm_menu(settings)
    elif choice == "3":
        settings["debug"] = not settings["debug"]
        com_func.save_json("req/options.json", settings)

        return main("Debug modu değiştirildi.")
    elif choice == "4":
        import index

        return index.main()
    else:

        return main("Girilen değer geçersiz.")

if __name__ == "__main__":
    main()